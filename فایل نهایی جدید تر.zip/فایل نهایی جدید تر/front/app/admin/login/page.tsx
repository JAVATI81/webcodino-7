"use client";

import Image from "next/image";
import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";

export default function AdminLoginPage() {
  const router = useRouter();
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [remember, setRemember] = useState(true);

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!identifier.trim() || !password) {
      alert("ایمیل/نام کاربری و رمز عبور را وارد کنید.");
      return;
    }
    const res = await fetch("/api/admin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ identifier, password, remember }),
    });
    if (res.ok) router.push("/admin");
    else alert("ورود ناموفق بود.");
  }

  return (
    <section className="mt-6 sm:mt-8">
      <div className="mx-auto w-full max-w-md space-y-5">
        <div className="flex justify-center">
          <Image src="/globe.svg" alt="لوگو" width={56} height={56} />
        </div>
        <h1 className="text-2xl font-bold text-center">ورود مدیر</h1>

        <form onSubmit={submit} className="grid grid-cols-1 gap-4 border rounded-2xl p-5 bg-background">
          <div>
            <label className="block text-sm mb-1">ایمیل یا نام کاربری</label>
            <input
              className="w-full rounded-lg border px-3 py-2 bg-background ltr:text-left"
              placeholder="admin@example.com"
              value={identifier}
              onChange={(e) => setIdentifier(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm mb-1">رمز عبور</label>
            <div className="flex items-center gap-2">
              <input
                type={showPass ? "text" : "password"}
                className="w-full rounded-lg border px-3 py-2 bg-background ltr:text-left"
                placeholder="********"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <button
                type="button"
                className="rounded border px-3 py-2 text-xs bg-background hover:bg-blue-50"
                onClick={() => setShowPass((s) => !s)}
              >
                {showPass ? "مخفی" : "نمایش"}
              </button>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <label className="flex items-center gap-2 text-sm cursor-pointer">
              <input
                type="checkbox"
                className="size-4 accent-blue-600"
                checked={remember}
                onChange={(e) => setRemember(e.target.checked)}
              />
              <span>مرا به خاطر بسپار</span>
            </label>
          </div>
          <div className="flex justify-center">
            <button className="rounded-xl bg-blue-600 text-white px-5 py-2 text-base hover:bg-blue-700">
              ورود به پنل ادمین
            </button>
          </div>
        </form>
      </div>
    </section>
  );
}


