"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

const buttons: Array<{ href: string; label: string; icon: string }> = [
  { href: "/admin/users", label: "مدیریت کاربران", icon: "👥" },
  { href: "/admin/products", label: "مدیریت محصولات", icon: "📦" },
  { href: "/admin/orders", label: "مدیریت سفارشات", icon: "🛒" },
  { href: "/admin/tickets", label: "تیکت‌ها", icon: "📧" },
  { href: "/admin/projects", label: "پروژه‌ها", icon: "🚀" },
  { href: "/admin/finance", label: "مدیریت مالی", icon: "💰" },
  { href: "/admin/coupons", label: "کدهای تخفیف", icon: "🎁" },
];

type DashboardStats = {
  totalUsers: number;
  totalProducts: number;
  totalOrders: number;
  totalTickets: number;
  totalProjects: number;
  totalCoupons: number;
  recentOrders: Array<{ id: string; amount: string; status: string; date: string }>;
  recentTickets: Array<{ id: string; subject: string; status: string; date: string }>;
};

export default function AdminDashboardPage() {
  const [stats, setStats] = useState<DashboardStats>({
    totalUsers: 0,
    totalProducts: 0,
    totalOrders: 0,
    totalTickets: 0,
    totalProjects: 0,
    totalCoupons: 0,
    recentOrders: [],
    recentTickets: [],
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // شبیه‌سازی دریافت آمار از API
    setTimeout(() => {
      setStats({
        totalUsers: 1250,
        totalProducts: 45,
        totalOrders: 89,
        totalTickets: 23,
        totalProjects: 67,
        totalCoupons: 12,
        recentOrders: [
          { id: "ORD-001", amount: "2,500,000 تومان", status: "تکمیل شده", date: "1403/05/20" },
          { id: "ORD-002", amount: "1,800,000 تومان", status: "در انتظار", date: "1403/05/19" },
          { id: "ORD-003", amount: "3,200,000 تومان", status: "فعال", date: "1403/05/18" },
        ],
        recentTickets: [
          { id: "TKT-001", subject: "مشکل در ورود به حساب", status: "باز", date: "1403/05/20" },
          { id: "TKT-002", subject: "سوال درباره محصولات", status: "پاسخ داده شده", date: "1403/05/19" },
          { id: "TKT-003", subject: "درخواست تمدید سرویس", status: "باز", date: "1403/05/18" },
        ],
      });
      setIsLoading(false);
    }, 1000);
  }, []);

  return (
    <section className="space-y-6">
      <h1 className="text-2xl font-bold">پنل مدیریت</h1>

      {/* آمار کلی */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <div className="bg-background border rounded-2xl p-4 text-center">
          <div className="text-2xl font-bold text-blue-600">{isLoading ? "..." : stats.totalUsers}</div>
          <div className="text-sm text-foreground/70">کل کاربران</div>
        </div>
        <div className="bg-background border rounded-2xl p-4 text-center">
          <div className="text-2xl font-bold text-green-600">{isLoading ? "..." : stats.totalProducts}</div>
          <div className="text-sm text-foreground/70">کل محصولات</div>
        </div>
        <div className="bg-background border rounded-2xl p-4 text-center">
          <div className="text-2xl font-bold text-purple-600">{isLoading ? "..." : stats.totalOrders}</div>
          <div className="text-sm text-foreground/70">کل سفارشات</div>
        </div>
        <div className="bg-background border rounded-2xl p-4 text-center">
          <div className="text-2xl font-bold text-orange-600">{isLoading ? "..." : stats.totalTickets}</div>
          <div className="text-sm text-foreground/70">کل تیکت‌ها</div>
        </div>
        <div className="bg-background border rounded-2xl p-4 text-center">
          <div className="text-2xl font-bold text-indigo-600">{isLoading ? "..." : stats.totalProjects}</div>
          <div className="text-sm text-foreground/70">کل پروژه‌ها</div>
        </div>
        <div className="bg-background border rounded-2xl p-4 text-center">
          <div className="text-2xl font-bold text-pink-600">{isLoading ? "..." : stats.totalCoupons}</div>
          <div className="text-sm text-foreground/70">کدهای تخفیف</div>
        </div>
      </div>

      {/* منوی دسترسی سریع */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {buttons.map((b) => (
          <Link
            key={b.href}
            href={b.href}
            className="rounded-2xl border p-6 text-center text-lg bg-background hover:bg-blue-600 hover:text-white transition-colors"
          >
            <div className="text-3xl mb-2">{b.icon}</div>
            <div>{b.label}</div>
          </Link>
        ))}
      </div>

      {/* آخرین سفارشات و تیکت‌ها */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* آخرین سفارشات */}
        <div className="border rounded-2xl p-5 bg-background">
          <h2 className="text-lg font-bold mb-4">آخرین سفارشات</h2>
          {isLoading ? (
            <div className="text-center text-foreground/70">در حال بارگذاری...</div>
          ) : (
            <div className="space-y-3">
                             {stats.recentOrders.map((order) => (
                 <div key={order.id} className="flex items-center justify-between p-3 bg-black rounded-lg">
                   <div>
                     <div className="font-medium text-white">{order.id}</div>
                     <div className="text-sm text-white">{order.amount}</div>
                   </div>
                   <div className="text-left">
                     <div className="text-sm font-medium text-white">{order.status}</div>
                     <div className="text-xs text-white">{order.date}</div>
                   </div>
                 </div>
               ))}
            </div>
          )}
        </div>

        {/* آخرین تیکت‌ها */}
        <div className="border rounded-2xl p-5 bg-background">
          <h2 className="text-lg font-bold mb-4">آخرین تیکت‌ها</h2>
          {isLoading ? (
            <div className="text-center text-foreground/70">در حال بارگذاری...</div>
          ) : (
            <div className="space-y-3">
                             {stats.recentTickets.map((ticket) => (
                 <div key={ticket.id} className="flex items-center justify-between p-3 bg-black rounded-lg">
                   <div>
                     <div className="font-medium text-white">{ticket.id}</div>
                     <div className="text-sm text-white">{ticket.subject}</div>
                   </div>
                   <div className="text-left">
                     <div className="text-sm font-medium text-white">{ticket.status}</div>
                     <div className="text-xs text-white">{ticket.date}</div>
                   </div>
                 </div>
               ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}


