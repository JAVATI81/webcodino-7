import { NextResponse } from "next/server";

// POST /api/account/logout
export async function POST() {
  // سشن کاربر را خاتمه دهید
  return NextResponse.json({ ok: true });
}


