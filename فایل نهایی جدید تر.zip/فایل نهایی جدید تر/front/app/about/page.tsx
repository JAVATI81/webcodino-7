"use client";

import Link from "next/link";
import Image from "next/image";
import { useEffect, useState } from "react";
import NoScroll from "@/components/NoScroll";
import { aboutItems } from "./data";

export default function AboutPage() {
  const [isDesktop, setIsDesktop] = useState(false);
  useEffect(() => {
    const handle = () => setIsDesktop(window.innerWidth >= 768);
    handle();
    window.addEventListener("resize", handle);
    return () => window.removeEventListener("resize", handle);
  }, []);

  return (
    <section className="mt-6 sm:mt-8">
      {isDesktop && <NoScroll />}
      <div className="grid grid-cols-1 md:grid-cols-[18%_82%] gap-6">
        {/* ستون راست: لوگو، شعار، دکمه */}
        <aside className="border rounded-2xl p-5 md:h-[70vh] md:order-none order-2 flex flex-col items-center justify-center gap-5 bg-background/20 backdrop-blur-sm">
          <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center">
            <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
            </svg>
          </div>
          <h2 className="text-2xl font-bold text-primary">وب کدینو</h2>
          <p className="text-center text-base sm:text-lg text-foreground/80">
            همراه مطمئن شما برای رشد دیجیتال.
          </p>
          <Link
            href="/contact"
            className="rounded-xl bg-primary text-white px-5 py-2 text-base sm:text-lg hover:bg-primary-light"
          >
            مشاوره رایگان
          </Link>
        </aside>

        {/* ستون چپ: آکاردئون درباره ما با اسکرول */}
        <main className="order-1 md:order-none border rounded-2xl p-5 h-auto md:h-[70vh] md:overflow-y-auto [direction:rtl] md:pr-3 bg-background/20 backdrop-blur-sm">
          <div className="[direction:rtl] space-y-3">
            {aboutItems.map((item) => (
              <details key={item.slug} className="border rounded-xl p-4 bg-background">
                <summary className="cursor-pointer text-base sm:text-lg font-semibold">
                  {item.title}
                </summary>
                <div className="mt-3 text-foreground/80 text-sm sm:text-base leading-7">
                  {item.content}
                </div>
              </details>
            ))}
          </div>
        </main>
      </div>
    </section>
  );
}


