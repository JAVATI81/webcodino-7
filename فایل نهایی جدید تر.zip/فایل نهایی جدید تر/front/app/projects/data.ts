export type Project = {
  id: number;
  title: string;
  desc: string;
  category: string;
  subcategory: string;
  price: string;
  link?: string;
};

export const allProjects: Project[] = [
  { id: 1, title: "پروژه سایت فروشگاهی", desc: "راه‌اندازی فروش آنلاین", category: "سایت", subcategory: "فروشگاهی", price: "۲,۰۰۰,۰۰۰", link: "/projects" },
  { id: 2, title: "پروژه سایت شرکتی", desc: "معرفی خدمات و برند", category: "سایت", subcategory: "شرکتی", price: "۱,۵۰۰,۰۰۰", link: "/projects" },
  { id: 3, title: "پروژه وبلاگ", desc: "انتشار مقالات و محتوا", category: "سایت", subcategory: "وبلاگ", price: "۸۰۰,۰۰۰", link: "/projects" },
  { id: 4, title: "اپلیکیشن فروشگاهی", desc: "Android و iOS", category: "اپلیکیشن", subcategory: "فروشگاهی", price: "۵,۰۰۰,۰۰۰", link: "/projects" },
  { id: 5, title: "ربات تلگرام", desc: "اتوماسیون و فروش", category: "ربات", subcategory: "تلگرام", price: "۱,۵۰۰,۰۰۰", link: "/projects" },
  { id: 6, title: "پروژه تولید ویدیو", desc: "موشن و پرومو", category: "تولید محتوا", subcategory: "تولید ویدیو", price: "۱,۸۰۰,۰۰۰", link: "/projects" },
];


