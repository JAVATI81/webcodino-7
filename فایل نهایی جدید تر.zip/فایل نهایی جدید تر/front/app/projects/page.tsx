"use client";

import { useEffect, useMemo, useState } from "react";
import NoScroll from "@/components/NoScroll";
import type { Project } from "./data";

// فهرست فیلترها برای پروژه‌ها (بدون هاست و سرور)
const projectCategoryToSubcategories: Record<string, string[]> = {
  "سایت": ["فروشگاهی", "شرکتی", "پزشکی", "وبلاگ", "اختصاصی", "رزومه‌ای"],
  "اپلیکیشن": ["فروشگاهی", "پزشکی", "اختصاصی"],
  "ربات": ["تلگرام", "اینستاگرام", "بله"],
  "تولید محتوا": ["فتوشاپ", "تولید ویدیو", "محتوا نویسی"],
};

// پروژه‌ها از API دریافت می‌شوند

export default function ProjectsPage() {
  // همسان با محصولات: اسکرول کلی صفحه فقط در دسکتاپ غیرفعال شود
  const [isDesktop, setIsDesktop] = useState(false);
  useEffect(() => {
    const handle = () => setIsDesktop(window.innerWidth >= 768);
    handle();
    window.addEventListener("resize", handle);
    return () => window.removeEventListener("resize", handle);
  }, []);
  const [openCategories, setOpenCategories] = useState<Record<string, boolean>>({});
  const [selected, setSelected] = useState<Record<string, Set<string>>>(() => {
    const initial: Record<string, Set<string>> = {};
    Object.keys(projectCategoryToSubcategories).forEach((c) => (initial[c] = new Set()));
    return initial;
  });

  const [projects, setProjects] = useState<Project[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const selectedSubSet = useMemo(() => {
    const set = new Set<string>();
    Object.values(selected).forEach((s) => s.forEach((x) => set.add(x)));
    return set;
  }, [selected]);

  useEffect(() => {
    const controller = new AbortController();
    async function load() {
      try {
        setIsLoading(true);
        const params = selectedSubSet.size
          ? `?subcategories=${encodeURIComponent(Array.from(selectedSubSet).join(","))}`
          : "";
        const res = await fetch(`/api/projects${params}`, { cache: "no-store", signal: controller.signal });
        const data = await res.json();
        setProjects(Array.isArray(data?.items) ? data.items : []);
      } catch (_e) {
        setProjects([]);
      } finally {
        setIsLoading(false);
      }
    }
    load();
    return () => controller.abort();
  }, [selectedSubSet]);

  function toggleCategoryOpen(category: string) {
    setOpenCategories((prev) => ({ ...prev, [category]: !prev[category] }));
  }

  function toggleSubcategory(category: string, sub: string) {
    setSelected((prev) => {
      const copy: Record<string, Set<string>> = { ...prev };
      const set = new Set(copy[category]);
      if (set.has(sub)) set.delete(sub);
      else set.add(sub);
      copy[category] = set;
      return copy;
    });
  }

  return (
    <section className="mt-6 sm:mt-8">
      {isDesktop && <NoScroll />}
      <div className="grid grid-cols-1 md:grid-cols-[18%_82%] gap-6">
        {/* ستون راست: فیلترها */}
        <aside className="border rounded-2xl p-5 order-1 md:order-none md:h-[70vh] md:overflow-y-auto [direction:rtl] bg-background/20 backdrop-blur-sm">
          <div className="[direction:rtl]">
            <h2 className="text-xl font-bold mb-4">فیلتر پروژه‌ها</h2>
            <div className="flex flex-col">
              {Object.entries(projectCategoryToSubcategories).map(([category, subs]) => {
                const isOpen = !!openCategories[category];
                const selectedCount = selected[category]?.size ?? 0;
                return (
                  <div key={category} className="border-b last:border-b-0 py-2">
                    <button
                      type="button"
                      className="w-full flex items-center justify-between text-right text-base sm:text-lg px-1 py-2 hover:text-blue-600"
                      onClick={() => toggleCategoryOpen(category)}
                      aria-expanded={isOpen}
                      aria-controls={`sub-${category}`}
                    >
                      <span className="flex items-center gap-2">
                        <span>{category}</span>
                        {selectedCount > 0 && (
                          <span className="text-xs rounded-full bg-blue-100 text-blue-700 px-2 py-0.5">
                            {selectedCount}
                          </span>
                        )}
                      </span>
                      <span className={`transition-transform ${isOpen ? "rotate-180" : "rotate-0"}`}>
                        ▾
                      </span>
                    </button>
                    {isOpen && (
                      <div id={`sub-${category}`} className="mt-2 pr-3 flex flex-col gap-2">
                        {subs.map((sub) => {
                          const checked = selected[category]?.has(sub) ?? false;
                          return (
                            <label key={sub} className="flex items-center gap-2 cursor-pointer text-sm sm:text-base">
                              <input
                                type="checkbox"
                                className="size-4 accent-blue-600"
                                checked={checked}
                                onChange={() => toggleSubcategory(category, sub)}
                              />
                              <span>{sub}</span>
                            </label>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </aside>

        {/* ستون چپ: کارت‌های پروژه */}
        <main className="order-2 md:order-none border rounded-2xl p-5 md:h-[70vh] md:overflow-y-auto md:[direction:rtl] bg-background/20 backdrop-blur-sm">
          <div className="[direction:rtl] grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 items-stretch">
            {isLoading && (
              <div className="col-span-3 text-center text-foreground/70 py-10">در حال بارگذاری...</div>
            )}
            {!isLoading && projects.map((p) => (
              <article
                key={p.id}
                className="h-full min-h-56 border rounded-2xl p-4 bg-background flex flex-col"
              >
                <h3 className="text-xl font-bold mb-2">{p.title}</h3>
                <p className="text-foreground/70 text-base">{p.desc}</p>
              <div className="mt-auto pt-4 flex items-center justify-center">
                {p.link ? (
                  <a
                    href={p.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="rounded-xl border px-4 py-2 text-base hover:bg-blue-600 hover:text-white"
                  >
                    مشاهده نمونه کار
                  </a>
                ) : (
                  <span className="rounded-xl border px-4 py-2 text-base text-foreground/50">مشاهده نمونه کار</span>
                )}
              </div>
              </article>
            ))}
            {!isLoading && projects.length === 0 && (
              <div className="col-span-3 text-center text-foreground/70 py-10">پروژه‌ای مطابق فیلترها یافت نشد.</div>
            )}
          </div>
        </main>
      </div>
    </section>
  );
}


