"use client";

import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

type FormType = "login" | "register";

export default function AuthPage() {
  const router = useRouter();
  const [activeForm, setActiveForm] = useState<FormType>("login"); // تغییر به login به عنوان پیش‌فرض
  const [isLoading, setIsLoading] = useState(false);

  // فرم لاگین
  const [loginData, setLoginData] = useState({
    identifier: "",
    password: "",
    remember: true
  });
  const [showLoginPass, setShowLoginPass] = useState(false);

  // فرم ریجستر
  const [registerData, setRegisterData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    nationalCode: "",
    password: "",
    confirmPassword: ""
  });
  const [showRegisterPass, setShowRegisterPass] = useState(false);
  const [showConfirmPass, setShowConfirmPass] = useState(false);

  // تابع لاگین
  async function handleLogin(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!loginData.identifier.trim() || !loginData.password) {
      alert("ایمیل/نام کاربری و رمز عبور را وارد کنید.");
      return;
    }

    setIsLoading(true);
    try {
      const res = await fetch("/api/account/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(loginData),
      });
      
      if (res.ok) {
        router.push("/account");
      } else {
        alert("ورود ناموفق بود. لطفاً اطلاعات خود را بررسی کنید.");
      }
    } catch (error) {
      alert("خطا در ارتباط با سرور.");
    } finally {
      setIsLoading(false);
    }
  }

  // تابع ریجستر
  async function handleRegister(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    
    if (!registerData.firstName.trim() || !registerData.lastName.trim()) {
      alert("نام و نام خانوادگی الزامی است.");
      return;
    }
    
    if (!registerData.email.trim()) {
      alert("ایمیل الزامی است.");
      return;
    }
    
    if (!registerData.phone.trim()) {
      alert("شماره تلفن الزامی است.");
      return;
    }
    
    if (!registerData.nationalCode.trim()) {
      alert("کد ملی الزامی است.");
      return;
    }
    
    if (!registerData.password) {
      alert("رمز عبور الزامی است.");
      return;
    }
    
    if (registerData.password !== registerData.confirmPassword) {
      alert("تکرار رمز عبور با رمز عبور یکسان نیست.");
      return;
    }
    
    if (registerData.password.length < 6) {
      alert("رمز عبور باید حداقل 6 کاراکتر باشد.");
      return;
    }

    setIsLoading(true);
    try {
      const res = await fetch("/api/account/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(registerData),
      });
      
      if (res.ok) {
        alert("ثبت‌نام با موفقیت انجام شد.");
        setActiveForm("login"); // بعد از ثبت‌نام به فرم ورود برو
      } else {
        alert("ثبت‌نام ناموفق بود. لطفاً اطلاعات خود را بررسی کنید.");
      }
    } catch (error) {
      alert("خطا در ارتباط با سرور.");
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center bg-transparent p-3">
      <div className="max-w-2xl w-full">
        <div className="bg-background border border-border rounded-3xl shadow-2xl overflow-hidden relative">
          <div className="grid grid-cols-1 lg:grid-cols-2 relative py-4">
            
            {/* فرم ثبت‌نام - سمت چپ */}
            <div className={`p-4 items-center justify-center relative bg-transparent z-10 ${activeForm === "register" ? "flex" : "hidden"} lg:flex`}>
              <div className="w-full max-w-[18rem]">
                <div className="text-center mb-4">
                  <h1 className="text-xl font-bold text-foreground mb-1.5">ثبت‌نام کنید</h1>
                  <p className="text-foreground/70 text-sm">حساب کاربری جدید ایجاد کنید</p>
                </div>

                <form onSubmit={handleRegister} className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <input
                      type="text"
                      placeholder="نام"
                      value={registerData.firstName}
                      onChange={(e) => setRegisterData(prev => ({ ...prev, firstName: e.target.value }))}
                      className="rounded-xl border border-border px-4 py-2.5 bg-background text-foreground focus:outline-none focus:border-primary transition-colors placeholder:text-foreground/50"
                    />
                    <input
                      type="text"
                      placeholder="نام خانوادگی"
                      value={registerData.lastName}
                      onChange={(e) => setRegisterData(prev => ({ ...prev, lastName: e.target.value }))}
                      className="rounded-xl border border-border px-4 py-2.5 bg-background text-foreground focus:outline-none focus:border-primary transition-colors placeholder:text-foreground/50"
                    />
                  </div>
                  
                  <input
                    type="email"
                    placeholder="ایمیل"
                    value={registerData.email}
                    onChange={(e) => setRegisterData(prev => ({ ...prev, email: e.target.value }))}
                    className="w-full rounded-xl border border-border px-4 py-2.5 bg-background text-foreground focus:outline-none focus:border-primary transition-colors placeholder:text-foreground/50"
                  />
                  
                  <input
                    type="tel"
                    placeholder="شماره تلفن"
                    value={registerData.phone}
                    onChange={(e) => setRegisterData(prev => ({ ...prev, phone: e.target.value }))}
                    className="w-full rounded-xl border border-border px-4 py-2.5 bg-background text-foreground focus:outline-none focus:border-primary transition-colors placeholder:text-foreground/50"
                  />
                  
                  <input
                    type="text"
                    placeholder="کد ملی"
                    maxLength={10}
                    value={registerData.nationalCode}
                    onChange={(e) => setRegisterData(prev => ({ ...prev, nationalCode: e.target.value.replace(/\D/g, '') }))}
                    className="w-full rounded-xl border border-border px-4 py-2.5 bg-background text-foreground focus:outline-none focus:border-primary transition-colors placeholder:text-foreground/50"
                  />
                  
                  <div className="relative">
                    <input
                      type={showRegisterPass ? "text" : "password"}
                      placeholder="رمز عبور"
                      value={registerData.password}
                      onChange={(e) => setRegisterData(prev => ({ ...prev, password: e.target.value }))}
                      className="w-full rounded-xl border border-border px-4 py-2.5 pr-12 bg-background text-foreground focus:outline-none focus:border-primary transition-colors placeholder:text-foreground/50"
                    />
                    <button
                      type="button"
                      onClick={() => setShowRegisterPass(!showRegisterPass)}
                      className="absolute left-3 top-1/2 -translate-y-1/2 p-1.5 hover:bg-foreground/10 rounded-lg transition-colors"
                    >
                      <svg className="w-4 h-4 text-foreground/60" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        {showRegisterPass ? (
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.878 9.878L3 3m6.878 6.878L21 21" />
                        ) : (
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                        )}
                      </svg>
                    </button>
                  </div>
                  
                  <div className="relative">
                    <input
                      type={showConfirmPass ? "text" : "password"}
                      placeholder="تکرار رمز عبور"
                      value={registerData.confirmPassword}
                      onChange={(e) => setRegisterData(prev => ({ ...prev, confirmPassword: e.target.value }))}
                      className="w-full rounded-xl border border-border px-4 py-2.5 pr-12 bg-background text-foreground focus:outline-none focus:border-primary transition-colors placeholder:text-foreground/50"
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPass(!showConfirmPass)}
                      className="absolute left-3 top-1/2 -translate-y-1/2 p-1.5 hover:bg-foreground/10 rounded-lg transition-colors"
                    >
                      <svg className="w-4 h-4 text-foreground/60" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        {showConfirmPass ? (
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.878 9.878L3 3m6.878 6.878L21 21" />
                        ) : (
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                        )}
                      </svg>
                    </button>
                  </div>

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full rounded-xl bg-gradient-to-r from-primary to-accent text-white py-2.5 font-semibold hover:from-primary-light hover:to-accent/80 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                  >
                    {isLoading ? "در حال ثبت‌نام..." : "ثبت‌نام"}
                  </button>
                </form>
              </div>
            </div>

            {/* فرم ورود - سمت راست */}
            <div className={`p-4 items-center justify-center relative bg-transparent z-10 ${activeForm === "login" ? "flex" : "hidden"} lg:flex`}>
              <div className="w-full max-w-[18rem]">
                <div className="text-center mb-4">
                  <h1 className="text-xl font-bold text-foreground mb-1.5">سلام دوباره!</h1>
                  <p className="text-foreground/70 text-sm">خوش آمدید، دلتنگتان بودیم!</p>
                </div>

                <form onSubmit={handleLogin} className="space-y-3">
                  <div>
                    <input
                      type="text"
                      placeholder="نام کاربری"
                      value={loginData.identifier}
                      onChange={(e) => setLoginData(prev => ({ ...prev, identifier: e.target.value }))}
                      className="w-full rounded-xl border border-border px-4 py-2.5 bg-background text-foreground focus:outline-none focus:border-primary transition-colors placeholder:text-foreground/50"
                    />
                  </div>
                  
                  <div className="relative">
                    <input
                      type={showLoginPass ? "text" : "password"}
                      placeholder="رمز عبور"
                      value={loginData.password}
                      onChange={(e) => setLoginData(prev => ({ ...prev, password: e.target.value }))}
                      className="w-full rounded-xl border border-border px-4 py-2.5 pr-12 bg-background text-foreground focus:outline-none focus:border-primary transition-colors placeholder:text-foreground/50"
                    />
                    <button
                      type="button"
                      onClick={() => setShowLoginPass(!showLoginPass)}
                      className="absolute left-3 top-1/2 -translate-y-1/2 p-1.5 hover:bg-foreground/10 rounded-lg transition-colors"
                    >
                      <svg className="w-4 h-4 text-foreground/60" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        {showLoginPass ? (
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.878 9.878L3 3m6.878 6.878L21 21" />
                        ) : (
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                        )}
                      </svg>
                    </button>
                  </div>

                  <div className="text-right">
                    <Link href="/auth/forgot" className="text-primary hover:text-primary-light transition-colors text-sm">
                      فراموشی رمز عبور؟
                    </Link>
                  </div>

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full rounded-xl bg-gradient-to-r from-primary to-accent text-white py-2.5 font-semibold hover:from-primary-light hover:to-accent/80 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                  >
                    {isLoading ? "در حال ورود..." : "ورود"}
                  </button>
                </form>

                {/* بخش شبکه‌های اجتماعی حذف شد */}
              </div>
            </div>

            {/* کشویی آبی - نصف اندازه، روی یک فرم */}
            <div className={`hidden lg:block absolute top-0 bottom-0 left-0 w-1/2 bg-gradient-to-br from-primary to-accent transition-transform duration-700 ease-in-out z-20 ${
              activeForm === "register" ? "translate-x-0" : "translate-x-full"
            }`}>
              <div className="h-full flex items-center justify-center">
                <div className="text-center text-white">
                  <div className="w-24 h-24 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-5">
                    <svg className="w-12 h-12" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                    </svg>
                  </div>
                  <h2 className="text-2xl font-bold mb-3">وب‌کدینو</h2>
                  <p className="text-base opacity-90">بهترین راه‌حل‌های دیجیتال</p>
                </div>
              </div>
            </div>

            {/* دکمه‌های تغییر حالت */}
            <div className="absolute top-6 left-6 z-30">
              <button
                onClick={() => setActiveForm("register")}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                  activeForm === "register" 
                    ? "bg-white/20 text-white" 
                    : "bg-background/80 text-foreground hover:bg-background"
                }`}
              >
                ثبت‌نام
              </button>
            </div>
            <div className="absolute top-6 right-6 z-30">
              <button
                onClick={() => setActiveForm("login")}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                  activeForm === "login" 
                    ? "bg-white/20 text-white" 
                    : "bg-background/80 text-foreground hover:bg-background"
                }`}
              >
                ورود
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
