import Link from "next/link";
import { use } from "react";
import { allProducts, findProductById } from "../data";
import ProductTabs from "../ProductTabs";
import RelatedProducts from "../RelatedProducts";
import AddToCartButton from "../AddToCartButton";

export default function ProductDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const product = findProductById(Number(id));
  if (!product) {
    return (
      <section className="py-10">
        <h1 className="text-2xl font-bold mb-3">محصول یافت نشد</h1>
        <Link href="/products" className="text-blue-600 hover:underline">بازگشت به محصولات</Link>
      </section>
    );
  }
  return (
    <section className="mt-6 sm:mt-8 grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 border rounded-2xl p-6 bg-background">
        <h1 className="text-2xl sm:text-3xl font-bold mb-2">{product.title}</h1>
        <p className="text-foreground/80 leading-8 mb-4">
          {product.desc} — این سرویس با تمرکز بر کیفیت و پایداری ارائه می‌شود. می‌توانید بسته به نیازتان،
          منابع و امکانات متنوعی را انتخاب کنید. پشتیبانی اختصاصی و امکان ارتقا در هر زمان فراهم است.
        </p>
        <ProductTabs product={product} showCompare={false} />
      </div>
      <aside className="border rounded-2xl p-6 h-max bg-background">
        <div className="text-2xl font-extrabold text-green-500 mb-4">{product.price} تومان</div>
        <div className="space-y-2">
          <AddToCartButton product={{ id: product.id, title: product.title, price: product.price }} />
          <Link href="/contact" className="block w-full text-center rounded-xl border px-5 py-2 text-base hover:bg-blue-50">مشاوره رایگان</Link>
        </div>
      </aside>
      <div className="lg:col-span-3">
        <h2 className="text-xl font-bold mb-3">پیشنهادات مرتبط</h2>
        <RelatedProducts items={allProducts.filter((p) => p.id !== product.id)} />
      </div>
    </section>
  );
}


